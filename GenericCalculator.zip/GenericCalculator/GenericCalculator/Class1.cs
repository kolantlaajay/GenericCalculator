﻿using System;

namespace GenericCalculator
{
    public class Class1
    {
    }
}
